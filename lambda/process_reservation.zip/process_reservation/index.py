import boto3
import uuid

dynamodb = boto3.resource("dynamodb")
ses = boto3.client("ses")
table = dynamodb.Table("Reservations")

def lambda_handler(event, context):
    slots = event["currentIntent"]["slots"]

    reservation_id = str(uuid.uuid4())
    reservation_data = {
        "ReservationID": reservation_id,
        "FirstName": slots["firstName"],
        "PhoneNumber": slots["phoneNumber"],
        "PartySize": slots["partySize"],
        "Date": slots["date"],
        "Time": slots["time"]
    }

    table.put_item(Item=reservation_data)
    send_email(slots["phoneNumber"] + "@example.com", slots["firstName"], reservation_id)

    return {
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
            "message": {
                "contentType": "PlainText",
                "content": f"Your reservation is confirmed, {slots['firstName']}! Your confirmation ID is {reservation_id}."
            }
        }
    }

def send_email(to_address, first_name, reservation_id):
    subject = "Your Reservation is Confirmed!"
    body = f"Hello {first_name},\n\nYour reservation is confirmed. Your confirmation ID is {reservation_id}.\n\nThank you!"

    response = ses.send_email(
        Source="your-email@example.com",
        Destination={"ToAddresses": [to_address]},
        Message={
            "Subject": {"Data": subject},
            "Body": {"Text": {"Data": body}}
        }
    )
    return response
